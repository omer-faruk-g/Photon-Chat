# Photon Chat (KNK) — FIP Tabanlı Mesajlaşma (Flutter)

Telefon numarası ya da e-posta gerektirmeyen, 5 haneli koda dayalı
arkadaşlık eşleştirmesi ve özel sohbet uygulaması.

Uygulama kullanıcıya gösterilen adıyla **Photon Chat**, iç kod adı
`photon_chat` (eski adı `knk_messenger`/KNK).

> **Gereksinim**: Flutter 3.16 veya üzeri (Dart SDK >= 3.2). Bu proje
> `PopScope` widget'ını kullanır; daha eski Flutter sürümlerinde
> `PopScope` mevcut değildir ve derleme hatası alırsınız. Sürümünüzü
> kontrol etmek için `flutter --version`, güncellemek için
> `flutter upgrade` çalıştırın.

## Proje yapısı

```
knk_flutter/
├── assets/
│   └── icon/
│       ├── icon.png              # Ana uygulama ikonu (1024x1024)
│       └── icon_foreground.png   # Android adaptive icon ön katmanı
├── lib/
│   ├── main.dart                 # Giriş noktası
│   ├── root_gate.dart            # Kimlik var mı? -> Onboarding veya Kişiler
│   ├── onboarding_screen.dart    # FIP oluşturma + FipCard widget'ı
│   ├── fip.dart                  # FIP üretimi, hash, 5 haneli kod türetme
│   ├── local_store.dart          # Cihaz içi depolama (kimlik, kişiler)
│   ├── knk_api.dart               # Sunucu ile iletişim katmanı
│   ├── obfuscate.dart            # Mesaj obfuskasyonu
│   ├── theme.dart                 # Renkler, stiller
│   └── screens/
│       ├── contacts_screen.dart   # Kişiler listesi + senkronizasyon
│       ├── add_contact_screen.dart# Kod ile arkadaş ekleme
│       ├── chat_screen.dart       # Özel sohbet
│       └── settings_screen.dart   # FIP görüntüleme + hesap silme
├── server/
│   ├── index.js                   # Eşleştirme/röle sunucusu (Express)
│   └── package.json
└── pubspec.yaml
```

## Tek kod tabanından beş platform

Bu proje **tek bir Dart kod tabanıdır**. Aynı `lib/` klasöründen
Android, iOS, HarmonyOS, Windows ve Linux için ayrı paketler üretilir;
kullanıcı kendi mağazasından/yükleyicisinden indirdiğinde zaten kendi
platformuna ait sürümü alır — ekstra bir "algıla ve kur" mekanizmasına
ihtiyaç yoktur.

### Android (.apk / .aab)

```bash
flutter pub get
flutter build apk --release        # test/yan yükleme için .apk
flutter build appbundle --release  # Play Store için .aab
```//

### iOS (.ipa)

```bash
flutter pub get
flutter build ipa --release
```
> macOS + Xcode gerektirir. App Store Connect üzerinden yayınlanır.

### HarmonyOS (.hap)

Flutter'ın resmi HarmonyOS desteği `flutter_ohos` eklentisi ile sağlanır
(OpenHarmony SIG). Genel adımlar:

```bash
flutter pub get
flutter build hap --release
```
> DevEco Studio kurulu bir ortamda, `ohos` platform klasörü eklenerek
> derlenir. AppGallery Connect üzerinden yayınlanır.

### Windows (.exe)

Flutter, Windows masaüstünü resmi olarak destekler. Bu proje şu anda
sadece `lib/`, `pubspec.yaml` ve `assets/` içerir; `windows/` platform
klasörü Flutter SDK'sı tarafından otomatik üretilir.

```bash
flutter config --enable-windows-desktop   # bir kerelik
flutter create .                          # eksik platform klasörlerini
                                           # (windows/, linux/ vb.) bu projeye ekler,
                                           # mevcut lib/ ve pubspec.yaml'a dokunmaz
flutter pub get
flutter pub run flutter_launcher_icons    # Windows .ico dahil ikonları üretir
flutter build windows --release
```

Çıktı: `build/windows/x64/runner/Release/` altında `photon_chat.exe` ve
gerekli DLL'ler. Bu klasörü olduğu gibi paylaşabilir veya bir kurulum
paketi (örn. Inno Setup, MSIX) ile sarmalayabilirsiniz.

### Linux (.deb / AppImage / tar.gz)

```bash
flutter config --enable-linux-desktop     # bir kerelik
flutter create .                          # linux/ platform klasörünü ekler
flutter pub get
flutter build linux --release
```

Derleme için sistemde `clang`, `cmake`, `ninja-build`, `pkg-config` ve
`libgtk-3-dev` paketleri kurulu olmalıdır (Ubuntu/Debian):

```bash
sudo apt install clang cmake ninja-build pkg-config libgtk-3-dev
```

Çıktı: `build/linux/x64/release/bundle/` altında çalıştırılabilir dosya
ve bağımlılıklar. Bu klasörü `tar.gz` olarak paylaşabilir, ya da
`flutter_distributor` gibi araçlarla `.deb`/AppImage paketine
dönüştürebilirsiniz.

> Not: `flutter_launcher_icons` Linux için ikon üretmez — Linux'ta
> uygulama ikonu `.desktop` dosyası ile birlikte ayrı bir PNG olarak
> dağıtılır. `assets/icon/icon.png` dosyasını kurulum paketinizle
> birlikte `/usr/share/icons/hicolor/512x512/apps/photon-chat.png`
> gibi bir yola kopyalayıp `.desktop` dosyasında `Icon=photon-chat`
> şeklinde referans verebilirsiniz.

## Uygulama ikonu

`assets/icon/icon.png` (1024x1024) ve `assets/icon/icon_foreground.png`
(Android adaptive icon ön katmanı) dosyaları yüklediğiniz Photon Chat
logosundan türetilmiştir. Tüm platformlar için ikonları yeniden üretmek
için:

```bash
flutter pub get
flutter pub run flutter_launcher_icons
```

Bu komut Android, iOS, Windows ve macOS ikonlarını otomatik günceller.
Linux için yukarıdaki notu izleyin.

## Backend (eşleştirme sunucusu)

Mesajların ve 5 haneli kod eşleştirmesinin cihazlar arasında ulaşması için
hafif bir röle sunucusu gerekir (bkz. "Sorun 1/2" — tek dosyanın internet
olmadan cihazlar arası veri taşıması fiziksel olarak mümkün değildir).

```bash
cd server
npm install
npm start
```

Sunucu:
- Telefon numarası / e-posta İSTEMEZ, saklamaz.
- Sadece fipId + 5 haneli kod + görünen ad (dizin), bekleyen istekler ve
  şifreli/obfuske mesaj kuyruklarını RAM'de tutar — kalıcı veritabanı yok.
- `/deactivate` çağrıldığında, ilgili kullanıcının dizin kaydı, bekleyen
  istekleri ve dahil olduğu TÜM sohbetler kalıcı silinir; hiçbir işlem
  loglanmaz.

`lib/knk_api.dart` içindeki `baseUrl` değerini kendi sunucu adresinizle
güncelleyin.

## Yeni özellikler: çıkışta loglama tercihi & deaktif kişi uyarısı

### Çıkışta "sohbetler kaydedilsin mi?"

Kullanıcı kişiler ekranındayken sistem geri tuşuyla uygulamadan çıkmaya
çalıştığında (aktif sohbeti olan en az bir kişi varsa) bir dialog gösterilir:

- **"Evet, sakla"** → sohbetler sunucuda olduğu gibi kalır, bir dahaki
  girişte geçmiş görünür.
- **"Hayır, imha et"** → bu cihazın dahil olduğu tüm aktif sohbetler
  `DELETE /chat/:chatKey` ile sunucudan kalıcı olarak silinir; karşı taraf
  tekrar girdiğinde sohbet temiz görünür. Bu işlem loglanmaz.

Bu, `/deactivate` (hesabı tamamen silme) ile karıştırılmamalı: kullanıcı
hesabını silmeden sadece uygulamadan çıkıyor, kimliği ve kişi listesi
cihazda kalır.

### Deaktif kişiye mesaj uyarısı

Sohbet ekranı, 5 saniyede bir karşı tarafın hâlâ aktif olup olmadığını
`POST /active` ile kontrol eder (`KnkApi.isActive`). Karşı taraf hesabını
sildiyse (deaktif olduysa):

- Mesaj alanının üstünde kırmızı bir uyarı şeridi görünür.
- Kullanıcı mesaj göndermeye çalışırsa, mesaj gönderilmeden önce bir
  diyalog ile "bu kişi artık aktif değil, mesajın iletilmeyecek" bilgisi
  verilir.

## Yeni/Değişen endpointler (server/index.js)

- `DELETE /chat/:chatKey` — sohbeti kalıcı olarak siler (kullanıcı
  "imha et" derse).
- `POST /active` — zaten vardı; tek bir fipId için de `KnkApi.isActive`
  ile kullanılabilir.

## Üretim için ek öneriler

- **Uçtan uca şifreleme**: Şu anki `obfuscate.dart` sadece görsel
  gizleme yapar, kriptografik güvenlik sağlamaz. Üretimde her FIP
  çifti için anahtar değişimi (örn. X25519) + AES-GCM önerilir; sunucu
  yalnızca şifreli blob'u taşır, içeriği hiç göremez.
- **Presence TTL**: Cihazlar belirli aralıklarla `/presence` çağırmalı;
  sunucu, uzun süre sinyal göndermeyen kayıtları otomatik temizlemeli.
- **Push bildirimleri**: Polling yerine WebSocket veya push servisi
  kullanmak pil ömrünü iyileştirir.
