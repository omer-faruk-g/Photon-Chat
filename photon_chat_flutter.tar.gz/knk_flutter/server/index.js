/**
 * KNK Sunucusu
 * ------------
 * Bu sunucu KİMLİK DOĞRULAMASI YAPMAZ. Telefon numarası, e-posta veya
 * herhangi bir kişisel kimlik bilgisi istemez/saklamaz.
 *
 * Sadece şunları tutar (tamamı RAM içinde; kalıcı veritabanı/log YOK):
 *  - presence:  fipId -> { code, name, lastSeen }      (aktif cihazlar dizini)
 *  - requests:  toFipId -> [ { fromFipId, fromCode, fromName } ]
 *  - accepted:  fipId -> Set<otherFipId>               (kabul bildirimleri)
 *  - chats:     chatKey -> [ { from, text, ts } ]      (obfuske/şifreli mesajlar)
 *
 * Bir kullanıcı /deactivate çağırdığında:
 *  - presence kaydı silinir (artık "aktif" görünmez)
 *  - bu kullanıcıya/dan gelen tüm bekleyen istekler silinir
 *  - bu kullanıcının dahil olduğu TÜM sohbetler (chats) kalıcı silinir
 *
 * Hiçbir silme işlemi loglanmaz; veriler sadece bellekten kaldırılır.
 *
 * NOT: Bu basit bir referans implementasyondur. Üretimde:
 *  - presence kayıtları için TTL (örn. 30 gün hareketsizlik -> otomatik silme)
 *  - HTTPS/TLS zorunlu
 *  - rate limiting
 *  - mesajlar için gerçek uçtan uca şifreleme (sunucu yalnızca şifreli blob taşır)
 * eklenmesi önerilir.
 */

const express = require('express');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

// ---- Bellek içi depolar (kalıcı veritabanı yok) ----
const presence = new Map(); // fipId -> { code, name, lastSeen }
const requests = new Map(); // toFipId -> [{ fromFipId, fromCode, fromName }]
const accepted = new Map(); // fipId -> Set(otherFipId)
const chats = new Map();    // chatKey -> [{ from, text, ts }]

function chatKeyFor(a, b) {
  return [a, b].sort().join('__');
}

// ---- Cihaz varlığını bildir / güncelle ----
app.post('/presence', (req, res) => {
  const { fipId, code, name } = req.body || {};
  if (!fipId || !code) return res.status(400).json({ error: 'fipId ve code gerekli' });
  presence.set(fipId, { code, name: name || 'Bilinmeyen', lastSeen: Date.now() });
  res.json({ ok: true });
});

// ---- 5 haneli koddan fipId bul ----
app.get('/lookup/:code', (req, res) => {
  const code = req.params.code;
  for (const [fipId, info] of presence.entries()) {
    if (info.code === code) {
      return res.json({ fipId, name: info.name });
    }
  }
  res.json({ fipId: null });
});

// ---- Arkadaşlık isteği gönder ----
app.post('/requests/:toFipId', (req, res) => {
  const toFipId = req.params.toFipId;
  const { fromFipId, fromCode, fromName } = req.body || {};
  if (!fromFipId || !fromCode) return res.status(400).json({ error: 'fromFipId ve fromCode gerekli' });

  const list = requests.get(toFipId) || [];
  if (!list.find((r) => r.fromFipId === fromFipId)) {
    list.push({ fromFipId, fromCode, fromName: fromName || 'Bilinmeyen' });
    requests.set(toFipId, list);
  }
  res.json({ ok: true });
});

// ---- Bana gelen bekleyen istekleri getir ----
app.get('/requests/:myFipId', (req, res) => {
  const myFipId = req.params.myFipId;
  res.json(requests.get(myFipId) || []);
});

// ---- İsteği kabul et ----
app.post('/accept', (req, res) => {
  const { myFipId, otherFipId } = req.body || {};
  if (!myFipId || !otherFipId) return res.status(400).json({ error: 'myFipId ve otherFipId gerekli' });

  // otherFipId'ye "myFipId seni kabul etti" bildirimi bırak
  const set = accepted.get(otherFipId) || new Set();
  set.add(myFipId);
  accepted.set(otherFipId, set);

  // myFipId'ye gelen istekler arasından otherFipId'yi kaldır
  const list = (requests.get(myFipId) || []).filter((r) => r.fromFipId !== otherFipId);
  requests.set(myFipId, list);

  res.json({ ok: true });
});

// ---- Gönderdiğim isteklerden kabul edilenleri getir (ve tüket) ----
app.get('/accepted/:myFipId', (req, res) => {
  const myFipId = req.params.myFipId;
  const set = accepted.get(myFipId) || new Set();
  const list = Array.from(set);
  accepted.delete(myFipId); // bir kez bildir, sonra temizle
  res.json(list);
});

// ---- Verilen fipId'lerden hangileri şu an aktif (silinmemiş)? ----
app.post('/active', (req, res) => {
  const { fipIds } = req.body || {};
  if (!Array.isArray(fipIds)) return res.status(400).json({ error: 'fipIds dizisi gerekli' });
  const active = fipIds.filter((id) => presence.has(id));
  res.json(active);
});

// ---- Sohbet mesajlarını getir ----
app.get('/chat/:chatKey', (req, res) => {
  res.json(chats.get(req.params.chatKey) || []);
});

// ---- Sohbete mesaj ekle ----
app.post('/chat/:chatKey', (req, res) => {
  const { from, text, ts } = req.body || {};
  if (!from || !text || !ts) return res.status(400).json({ error: 'from, text, ts gerekli' });
  const list = chats.get(req.params.chatKey) || [];
  list.push({ from, text, ts });
  chats.set(req.params.chatKey, list);
  res.json({ ok: true });
});

// ---- Bir sohbeti kalıcı olarak sil (kullanıcı "loglanmasın" derse) ----
app.delete('/chat/:chatKey', (req, res) => {
  chats.delete(req.params.chatKey);
  res.json({ ok: true });
});

// ---- Hesabı deaktif et: dizinden kaldır, sohbetleri imha et ----
app.post('/deactivate', (req, res) => {
  const { fipId } = req.body || {};
  if (!fipId) return res.status(400).json({ error: 'fipId gerekli' });

  // 1) dizinden kaldır -> diğer cihazlar artık "aktif değil" görür
  presence.delete(fipId);

  // 2) bu kullanıcıya/dan olan bekleyen istekleri sil
  requests.delete(fipId);
  for (const [to, list] of requests.entries()) {
    requests.set(to, list.filter((r) => r.fromFipId !== fipId));
  }
  accepted.delete(fipId);
  for (const set of accepted.values()) set.delete(fipId);

  // 3) bu kullanıcının dahil olduğu tüm sohbetleri kalıcı sil (loglanmadan)
  for (const key of Array.from(chats.keys())) {
    if (key.includes(fipId)) chats.delete(key);
  }

  res.json({ ok: true });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`KNK sunucusu ${PORT} portunda calisiyor (log tutulmaz, RAM-only depolama)`);
});
