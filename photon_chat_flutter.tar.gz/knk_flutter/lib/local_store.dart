import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import 'fip.dart';

/// Bir kişi/kişi-adayı kaydı.
class Contact {
  final String fipId;
  final String name;
  final String code;
  String status; // 'on' | 'pending_in' | 'pending_out'

  Contact({
    required this.fipId,
    required this.name,
    required this.code,
    required this.status,
  });

  Map<String, dynamic> toJson() => {
        'fipId': fipId,
        'name': name,
        'code': code,
        'status': status,
      };

  factory Contact.fromJson(Map<String, dynamic> json) => Contact(
        fipId: json['fipId'],
        name: json['name'],
        code: json['code'],
        status: json['status'],
      );
}

/// Bir sohbet mesajı.
class ChatMessage {
  final String from; // gönderenin fipId'si
  final String text;
  final int ts; // epoch ms

  ChatMessage({required this.from, required this.text, required this.ts});

  Map<String, dynamic> toJson() => {'from': from, 'text': text, 'ts': ts};

  factory ChatMessage.fromJson(Map<String, dynamic> json) => ChatMessage(
        from: json['from'],
        text: json['text'],
        ts: json['ts'],
      );
}

/// Tüm yerel depolama işlemlerini yöneten servis.
///
/// Kimlik (FIP bloğu) ve kişi listesi SADECE bu cihazda saklanır.
/// Hiçbir telefon numarası, e-posta veya kişisel kimlik bilgisi tutulmaz.
class LocalStore {
  static const _kIdentityKey = 'knk_identity_v1';
  static const _kContactsKey = 'knk_contacts_v1';
  static const _kDisplayNameKey = 'knk_display_name_v1';

  /// Kayıtlı kimlik var mı? Varsa döner, yoksa null.
  static Future<FipBlock?> loadIdentity() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_kIdentityKey);
    if (raw == null) return null;
    final json = jsonDecode(raw) as Map<String, dynamic>;
    return FipBlock.fromJson(json);
  }

  /// Yeni kimlik oluşturup cihaza kaydeder.
  static Future<FipBlock> createIdentity() async {
    final fip = FipBlock.generate();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_kIdentityKey, jsonEncode(fip.toJson()));
    return fip;
  }

  static Future<String?> loadDisplayName() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_kDisplayNameKey);
  }

  static Future<void> saveDisplayName(String name) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_kDisplayNameKey, name);
  }

  /// Kişi listesini yükler.
  static Future<List<Contact>> loadContacts() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_kContactsKey);
    if (raw == null) return [];
    final list = jsonDecode(raw) as List<dynamic>;
    return list.map((e) => Contact.fromJson(e as Map<String, dynamic>)).toList();
  }

  /// Kişi listesini kaydeder.
  static Future<void> saveContacts(List<Contact> contacts) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(
      _kContactsKey,
      jsonEncode(contacts.map((c) => c.toJson()).toList()),
    );
  }

  /// Hesabı bu cihazdan tamamen kaldırır (deaktivasyon).
  /// FIP bloğu, kişi listesi ve görünen ad cihazdan silinir.
  static Future<void> wipeIdentity() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_kIdentityKey);
    await prefs.remove(_kContactsKey);
    await prefs.remove(_kDisplayNameKey);
  }
}
