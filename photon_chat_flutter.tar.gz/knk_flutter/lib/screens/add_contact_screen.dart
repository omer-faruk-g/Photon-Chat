import 'package:flutter/material.dart';
import '../fip.dart';
import '../knk_api.dart';
import '../local_store.dart';
import '../theme.dart';

class AddContactScreen extends StatefulWidget {
  final FipBlock identity;
  final String displayName;

  const AddContactScreen({super.key, required this.identity, required this.displayName});

  @override
  State<AddContactScreen> createState() => _AddContactScreenState();
}

class _AddContactScreenState extends State<AddContactScreen> {
  final _codeCtrl = TextEditingController();
  String? _error;
  bool _sending = false;

  @override
  void dispose() {
    _codeCtrl.dispose();
    super.dispose();
  }

  Future<void> _send() async {
    final code = _codeCtrl.text.trim();
    if (code.length != 5) return;

    if (code == widget.identity.code) {
      setState(() => _error = 'Bu senin kendi kodun.');
      return;
    }

    setState(() {
      _sending = true;
      _error = null;
    });

    final target = await KnkApi.lookupByCode(code);
    if (target == null) {
      setState(() {
        _sending = false;
        _error = 'Bu koda sahip aktif bir kullanıcı bulunamadı.';
      });
      return;
    }

    final targetFipId = target['fipId'] as String;
    final targetName = (target['name'] as String?) ?? 'Bilinmeyen';

    await KnkApi.sendFriendRequest(
      toFipId: targetFipId,
      fromFipId: widget.identity.fipId,
      fromCode: widget.identity.code,
      fromName: widget.displayName,
    );

    if (!mounted) return;
    Navigator.pop(
      context,
      Contact(fipId: targetFipId, name: targetName, code: code, status: 'pending_out'),
    );
  }

  @override
  Widget build(BuildContext context) {
    final digits = _codeCtrl.text.replaceAll(RegExp(r'\D'), '');

    return Scaffold(
      appBar: AppBar(title: const Text('Kişi Ekle')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Container(
          margin: const EdgeInsets.only(top: 24),
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: KnkColors.panel,
            border: Border.all(color: KnkColors.line),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Column(
            children: [
              const Text(
                'KARŞI TARAFIN 5 HANELİ KODU',
                style: TextStyle(color: KnkColors.textDim, fontSize: 11, letterSpacing: 1.5),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: _codeCtrl,
                keyboardType: TextInputType.number,
                maxLength: 5,
                textAlign: TextAlign.center,
                autofocus: true,
                style: const TextStyle(
                  color: KnkColors.accent,
                  fontSize: 32,
                  fontWeight: FontWeight.w800,
                  letterSpacing: 12,
                ),
                decoration: InputDecoration(
                  counterText: '',
                  hintText: '00000',
                  hintStyle: const TextStyle(color: Color(0xFF5C6E6B), letterSpacing: 12),
                  filled: true,
                  fillColor: KnkColors.bg,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8),
                    borderSide: const BorderSide(color: KnkColors.line),
                  ),
                ),
                onChanged: (_) => setState(() {}),
              ),
              const SizedBox(height: 12),
              const Text(
                'Kod, karşı tarafın FIP bloğundan türetilmiştir ve cihazlar '
                'arasında paylaşılmadıkça hiçbir anlamı yoktur.',
                textAlign: TextAlign.center,
                style: TextStyle(color: KnkColors.textDim, fontSize: 11, height: 1.6),
              ),
              if (_error != null) ...[
                const SizedBox(height: 12),
                Text(_error!, style: const TextStyle(color: KnkColors.danger, fontSize: 12)),
              ],
              const SizedBox(height: 18),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      style: knkGhostButtonStyle(),
                      onPressed: () => Navigator.pop(context),
                      child: const Text('Vazgeç'),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: ElevatedButton(
                      style: knkPrimaryButtonStyle(),
                      onPressed: (digits.length == 5 && !_sending) ? _send : null,
                      child: _sending
                          ? const SizedBox(
                              width: 18,
                              height: 18,
                              child: CircularProgressIndicator(strokeWidth: 2, color: Color(0xFF06251A)),
                            )
                          : const Text('Davet gönder'),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
