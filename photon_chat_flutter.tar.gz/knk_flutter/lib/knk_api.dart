import 'dart:convert';
import 'package:http/http.dart' as http;

/// KNK eşleştirme/röle sunucusuyla iletişim katmanı.
///
/// Bu sunucu KİMLİK doğrulamaz, telefon numarası/e-posta istemez.
/// Yalnızca şu kayıtları tutar:
///  - fipId <-> 5 haneli kod eşlemesi (kullanıcı "aktif" olduğu sürece)
///  - bekleyen arkadaşlık istekleri
///  - aktif sohbetlerin şifreli mesaj kuyrukları
///
/// İki taraf da "deaktif" olduğunda (bkz. /deactivate), o sohbete dair
/// TÜM kayıtlar sunucudan kalıcı olarak silinir; hiçbir log tutulmaz.
///
/// Sunucu kaynak kodu: server/index.js (bu projeyle birlikte verilir).
class KnkApi {
  /// Kendi sunucunuzun adresiyle değiştirin.
  /// Geliştirme için: http://10.0.2.2:3000 (Android emulator -> localhost)
  static const String baseUrl = 'https://YOUR_KNK_SERVER.example.com';

  static Uri _u(String path) => Uri.parse('$baseUrl$path');

  /// Bu cihazı (fipId + kod + görünen ad) global dizine kaydeder/günceller.
  /// İsim sunucuda saklanmaz şeklinde de yapılandırılabilir; burada
  /// kullanıcı deneyimi için tutulur ama istenirse kaldırılabilir.
  static Future<void> registerPresence(String fipId, String code, String name) async {
    await http.post(
      _u('/presence'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'fipId': fipId, 'code': code, 'name': name}),
    );
  }

  /// 5 haneli koda karşılık gelen fipId'yi bulur. Bulunamazsa null döner.
  static Future<Map<String, dynamic>?> lookupByCode(String code) async {
    final res = await http.get(_u('/lookup/$code'));
    if (res.statusCode != 200) return null;
    final body = jsonDecode(res.body);
    if (body == null || body['fipId'] == null) return null;
    return body as Map<String, dynamic>;
  }

  /// Hedef fipId'ye arkadaşlık isteği gönderir.
  static Future<void> sendFriendRequest({
    required String toFipId,
    required String fromFipId,
    required String fromCode,
    required String fromName,
  }) async {
    await http.post(
      _u('/requests/$toFipId'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({
        'fromFipId': fromFipId,
        'fromCode': fromCode,
        'fromName': fromName,
      }),
    );
  }

  /// Bana gelen bekleyen arkadaşlık isteklerini getirir.
  static Future<List<Map<String, dynamic>>> getIncomingRequests(String myFipId) async {
    final res = await http.get(_u('/requests/$myFipId'));
    if (res.statusCode != 200) return [];
    final body = jsonDecode(res.body) as List<dynamic>;
    return body.cast<Map<String, dynamic>>();
  }

  /// Bir arkadaşlık isteğini kabul eder. Karşı taraf bir sonraki
  /// senkronizasyonda 'on' durumuna geçer.
  static Future<void> acceptFriendRequest({
    required String myFipId,
    required String otherFipId,
  }) async {
    await http.post(
      _u('/accept'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'myFipId': myFipId, 'otherFipId': otherFipId}),
    );
  }

  /// Gönderdiğim isteklerden hangileri kabul edildi, kontrol eder.
  static Future<List<String>> getAcceptedRequests(String myFipId) async {
    final res = await http.get(_u('/accepted/$myFipId'));
    if (res.statusCode != 200) return [];
    final body = jsonDecode(res.body) as List<dynamic>;
    return body.cast<String>();
  }

  /// Belirtilen fipId'lerin şu anda "aktif" (silinmemiş) olup olmadığını
  /// kontrol eder. Aktif olmayanlar -> karşı taraf hesabını sildi (deaktif).
  static Future<Set<String>> getActiveFipIds(List<String> fipIds) async {
    final res = await http.post(
      _u('/active'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'fipIds': fipIds}),
    );
    if (res.statusCode != 200) return {};
    final body = jsonDecode(res.body) as List<dynamic>;
    return body.cast<String>().toSet();
  }

  /// Sohbet mesajlarını getirir (şifreli/obfuske metin olarak).
  static Future<List<Map<String, dynamic>>> getMessages(String chatKey) async {
    final res = await http.get(_u('/chat/$chatKey'));
    if (res.statusCode != 200) return [];
    final body = jsonDecode(res.body) as List<dynamic>;
    return body.cast<Map<String, dynamic>>();
  }

  /// Belirtilen tek bir fipId'nin şu anda aktif olup olmadığını kontrol eder.
  static Future<bool> isActive(String fipId) async {
    final active = await getActiveFipIds([fipId]);
    return active.contains(fipId);
  }

  /// Sohbete yeni mesaj ekler.
  static Future<void> sendMessage({
    required String chatKey,
    required String from,
    required String text,
    required int ts,
  }) async {
    await http.post(
      _u('/chat/$chatKey'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'from': from, 'text': text, 'ts': ts}),
    );
  }

  /// Bir sohbeti kalıcı olarak siler (kullanıcı çıkışta "loglanmasın" derse).
  static Future<void> deleteChat(String chatKey) async {
    await http.delete(_u('/chat/$chatKey'));
  }

  /// Hesabı deaktif eder: sunucudaki dizin kaydını, bekleyen istekleri ve
  /// bu kullanıcıya ait sohbetleri kalıcı olarak siler. Loglanmaz.
  static Future<void> deactivate(String fipId) async {
    await http.post(
      _u('/deactivate'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'fipId': fipId}),
    );
  }
}
