import 'package:flutter/material.dart';
import 'fip.dart';
import 'local_store.dart';
import 'theme.dart';
import 'onboarding_screen.dart';
import 'screens/contacts_screen.dart';

/// Uygulama açılışında: kayıtlı kimlik var mı diye bakar.
/// Varsa doğrudan kişiler ekranına, yoksa onboarding'e yönlendirir.
class RootGate extends StatefulWidget {
  const RootGate({super.key});

  @override
  State<RootGate> createState() => RootGateState();
}

class RootGateState extends State<RootGate> {
  bool _loading = true;
  FipBlock? _identity;
  String _displayName = '';

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final identity = await LocalStore.loadIdentity();
    final name = await LocalStore.loadDisplayName();
    setState(() {
      _identity = identity;
      _displayName = name ?? '';
      _loading = false;
    });
  }

  /// Yerel depodaki kimliği yeniden okur. Hesap silindikten sonra
  /// (deaktivasyon) bu çağrılarak onboarding ekranına dönülmesi sağlanır.
  void reload() {
    setState(() => _loading = true);
    _load();
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Scaffold(
        backgroundColor: KnkColors.bg,
        body: Center(
          child: Text(
            'PHOTON CHAT KİMLİK DOĞRULANIYOR…',
            style: TextStyle(
              color: KnkColors.accent,
              fontFamily: 'monospace',
              fontSize: 12,
              letterSpacing: 1.2,
            ),
          ),
        ),
      );
    }

    if (_identity == null) {
      return OnboardingScreen(onCreated: (fip, name) {
        setState(() {
          _identity = fip;
          _displayName = name;
        });
      });
    }

    return ContactsScreen(identity: _identity!, displayName: _displayName);
  }
}
